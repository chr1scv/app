package com.example.evaluacion

class AuthenticationException(message: String) : Exception(message)
